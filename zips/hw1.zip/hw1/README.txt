I submitted my answers in hw1.txt. 
